An example created by the http://materializecss.com/ team. 
I just copied a version of this example in order to have a snapshot of it - that will be used for a tutorial, that
will convert it into a Drupal 8 theme.
